package fichiers;

public interface Lecteur{
	public void ouvrir();
	public void lire();
	public void affiche();
}
